const KEY = 'cityfix_reports_v2';
const CATS = { pothole: ['Яма на дороге', '🕳️'], trash: ['Несанкционированный мусор', '🗑️'], light: ['Сломанный фонарь', '💡'], graffiti: ['Граффити', '🎨'] };
const STATUS = { new: ['Новая', 'text-cyan-300 bg-cyan-400/10 border-cyan-400/30', 'border-l-cyan-400'], work: ['В работе', 'text-amber-300 bg-amber-400/10 border-amber-400/30', 'border-l-amber-400'], done: ['Решена', 'text-emerald-300 bg-emerald-400/10 border-emerald-400/30', 'border-l-emerald-400'] };
const SEED = [
  { id: 4850, cat: 'pothole', title: 'Яма на проезжей части по ул. Ахунбаева', addr: 'ул. Ахунбаева, 121', status: 'work', conf: 97.2, date: '09.10.2026' },
  { id: 4849, cat: 'light', title: 'Не работает уличное освещение у остановки', addr: 'пр. Чуй, 155', status: 'new', conf: 94.6, date: '09.10.2026' },
  { id: 4846, cat: 'trash', title: 'Стихийная свалка у контейнерной площадки', addr: 'мкр. Джал, 14', status: 'new', conf: 98.1, date: '09.10.2026' },
  { id: 4841, cat: 'pothole', title: 'Провал асфальта возле пешеходного перехода', addr: 'ул. Токтогула, 98', status: 'work', conf: 95.5, date: '08.10.2026' },
  { id: 4838, cat: 'graffiti', title: 'Граффити на фасаде подземного перехода', addr: 'ул. Исанова, 42', status: 'done', conf: 92.4, date: '08.10.2026' },
  { id: 4833, cat: 'light', title: 'Разбит плафон фонаря в сквере', addr: 'бул. Эркиндик, 30', status: 'new', conf: 93.0, date: '08.10.2026' },
  { id: 4829, cat: 'trash', title: 'Переполненные баки во дворе жилого дома', addr: 'ул. Дружбы, 7', status: 'work', conf: 96.3, date: '07.10.2026' },
  { id: 4824, cat: 'pothole', title: 'Глубокая выбоина на въезде во двор', addr: 'ул. Манаса, 63', status: 'done', conf: 97.8, date: '07.10.2026' },
  { id: 4818, cat: 'light', title: 'Не горят три фонаря вдоль тротуара', addr: 'ул. Московская, 210', status: 'work', conf: 94.1, date: '06.10.2026' },
  { id: 4812, cat: 'graffiti', title: 'Надписи на остановочном павильоне', addr: 'пр. Мира, 88', status: 'new', conf: 91.7, date: '06.10.2026' },
  { id: 4806, cat: 'trash', title: 'Строительный мусор на обочине', addr: 'ул. Малдыбаева, 33', status: 'done', conf: 98.4, date: '05.10.2026' },
  { id: 4799, cat: 'pothole', title: 'Просадка дорожного полотна после ремонта труб', addr: 'ул. Боконбаева, 15', status: 'work', conf: 95.0, date: '05.10.2026' },
  { id: 4791, cat: 'light', title: 'Мигающий светильник на площади', addr: 'пл. Ала-Тоо, 1', status: 'done', conf: 92.9, date: '04.10.2026' },
  { id: 4783, cat: 'trash', title: 'Мусор у детской площадки', addr: 'мкр. Асанбай, 22', status: 'new', conf: 96.0, date: '04.10.2026' }
];
const load = () => { try { return JSON.parse(localStorage.getItem(KEY)) || SEED; } catch { return SEED; } };
const save = r => { try { localStorage.setItem(KEY, JSON.stringify(r)); } catch {} };
const $ = s => document.querySelector(s);
const rnd = (a, b) => Math.random() * (b - a) + a;
const nextId = () => Math.max(...load().map(r => r.id)) + 1;
const today = () => new Date().toLocaleDateString('ru-RU');

function addReport(cat, title, addr, conf) {
  const r = { id: nextId(), cat, title, addr, status: 'new', conf, date: today() };
  save([r, ...load()]);
  return r;
}

/* ---------- shell ---------- */
function goBack() {
  const same = document.referrer && document.referrer.startsWith(location.origin) && !document.referrer.endsWith(location.pathname);
  if (same || history.length > 1) history.back();
  else location.href = document.body.dataset.page === 'dash' ? 'index.html' : 'dashboard.html';
}
function shell() {
  const page = document.body.dataset.page;
  const link = (h, t, k) => `<a href="${h}" class="px-3 py-2 rounded-lg text-sm font-semibold ${page === k ? 'text-cyan-300 bg-cyan-400/10' : 'text-zinc-400 hover:text-white'}">${t}</a>`;
  $('#header').innerHTML = `<div class="glass sticky top-0 z-40 border-x-0 border-t-0"><div class="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
    <div class="flex items-center gap-2"><button onclick="goBack()" aria-label="Назад" title="Назад" class="w-9 h-9 rounded-lg border border-zinc-700 hover:border-cyan-400 hover:text-cyan-300 grid place-items-center transition text-lg">←</button>
    <a href="index.html" class="display font-bold text-lg flex items-center gap-2"><span class="w-8 h-8 rounded-lg btn grid place-items-center">⌖</span>CityFix <span class="text-cyan-400">AI</span></a></div>
    <nav class="flex items-center gap-1">${link('index.html', 'Главная', 'home')}${link('index.html#catalog', 'Каталог', 'x')}${link('dashboard.html', 'Дашборд', 'dash')}</nav></div></div>`;
  $('#footer').innerHTML = `<div class="border-t border-zinc-800 mt-20 py-8 text-center text-sm text-zinc-500">© 2026 CityFix AI — умный город начинается с жителей<br><span class="text-cyan-400 font-semibold">by Qshackaton Ernest, Musa, Daniel</span></div>`;
}

/* ---------- modal ---------- */
function modal(html) {
  const m = $('#modal');
  m.innerHTML = `<div class="glass modal-in rounded-2xl p-6 w-full max-w-md">${html}</div>`;
  m.classList.remove('hidden'); m.classList.add('flex');
}
function closeModal() { const m = $('#modal'); m.classList.add('hidden'); m.classList.remove('flex'); }
function success(r) {
  modal(`<div class="text-center"><div class="w-16 h-16 mx-auto rounded-full bg-emerald-400/15 grid place-items-center text-3xl text-emerald-300">✓</div>
  <h3 class="text-xl font-bold mt-4">Успешно!</h3>
  <p class="text-zinc-300 mt-2">Заявка №${r.id} зарегистрирована и передана в городские службы</p>
  <p class="text-xs text-zinc-500 mt-2">${r.title} · уверенность ИИ ${r.conf.toFixed(1)}%</p>
  <div class="flex gap-2 mt-6"><a href="dashboard.html" class="btn flex-1 rounded-xl py-3">Открыть дашборд</a><button onclick="closeModal()" class="flex-1 rounded-xl py-3 border border-zinc-700 hover:border-zinc-500">Закрыть</button></div></div>`);
}

/* ---------- scanner (catalog) ---------- */
const CATALOG = [
  { cat: 'pothole', icon: '🕳️', title: 'Яма на проезжей части по ул. Ахунбаева', addr: 'ул. Ахунбаева, 121', desc: 'Разрушение асфальта 60×40 см, опасно для транспорта.' },
  { cat: 'light', icon: '💡', title: 'Не работает уличное освещение', addr: 'пр. Чуй, 155', desc: 'Три опоры подряд без света, тёмный участок у остановки.' },
  { cat: 'trash', icon: '🗑️', title: 'Несанкционированная свалка у дома', addr: 'мкр. Джал, 14', desc: 'Строительный и бытовой мусор рядом с контейнерами.' },
  { cat: 'graffiti', icon: '🎨', title: 'Граффити на стене перехода', addr: 'ул. Исанова, 42', desc: 'Надписи на фасаде подземного перехода.' }
];
function scan(i) {
  const c = CATALOG[i], conf = rnd(93, 99), lat = (42.8746 + rnd(-.03, .03)).toFixed(5), lng = (74.5698 + rnd(-.04, .04)).toFixed(5);
  modal(`<h3 class="font-bold mb-3">Сканер YOLOv8 · <span class="text-cyan-300">${c.title}</span></h3>
  <div class="scan-box rounded-xl h-48 grid place-items-center text-7xl"><span>${c.icon}</span><div class="scan-line"></div><div id="bb" class="bbox" style="left:28%;top:22%;width:44%;height:52%"></div></div>
  <div class="mt-4 h-2 rounded bg-zinc-800 overflow-hidden"><div id="bar" class="h-full btn" style="width:0;transition:width .3s"></div></div>
  <p id="st" class="text-sm text-cyan-300 mt-2">Инициализация модели…</p>
  <div id="res" class="text-sm text-zinc-300 mt-3 space-y-1"></div>`);
  const steps = [[20, 'Загрузка YOLOv8…'], [45, 'ИИ анализирует изображение…'], [70, 'Определяются координаты…'], [100, 'Классификация завершена']];
  steps.forEach(([p, t], k) => setTimeout(() => { $('#bar').style.width = p + '%'; $('#st').textContent = t; if (k === 2) $('#bb').classList.add('on'); }, 600 * (k + 1)));
  setTimeout(() => {
    const r = addReport(c.cat, c.title, c.addr, conf);
    $('#res').innerHTML = `<div>Класс: <b class="text-emerald-300">${CATS[c.cat][0]}</b></div><div>Уверенность: <b class="text-emerald-300">${conf.toFixed(1)}%</b></div><div>Координаты: <b>${lat}, ${lng}</b></div><div>Заявка <b>№${r.id}</b> добавлена в дашборд</div>
    <div class="flex gap-2 pt-3"><a href="dashboard.html" class="btn flex-1 rounded-xl py-2 text-center">В дашборд</a><button onclick="closeModal();renderRecent()" class="flex-1 rounded-xl py-2 border border-zinc-700">Закрыть</button></div>`;
  }, 3200);
}
function renderCatalog() {
  $('#catalogGrid').innerHTML = CATALOG.map((c, i) => `<article class="glass glow rounded-2xl p-5 transition flex flex-col">
    <div class="h-28 rounded-xl bg-slate-900 grid place-items-center text-5xl">${c.icon}</div>
    <h3 class="font-bold mt-4 text-sm">${c.title}</h3><p class="text-xs text-zinc-400 mt-1 flex-1">${c.desc}</p><p class="text-xs text-zinc-500 mt-2">📍 ${c.addr}</p>
    <button onclick="scan(${i})" class="btn rounded-xl py-2 mt-4 text-sm">Симулировать сканирование ИИ</button></article>`).join('');
}

/* ---------- reports ---------- */
const card = r => `<div class="glass glow border-l-4 ${STATUS[r.status][2]} rounded-2xl p-4 flex items-center gap-4 transition">
  <div class="w-12 h-12 shrink-0 rounded-xl bg-slate-900 grid place-items-center text-2xl">${CATS[r.cat][1]}</div>
  <div class="flex-1 min-w-0"><p class="font-semibold text-sm truncate">${r.title}</p><p class="text-xs text-zinc-500">№${r.id} · ${r.addr} · ${r.date} · ИИ ${r.conf.toFixed(1)}%</p></div>
  <span class="text-xs px-2.5 py-1 rounded-full border whitespace-nowrap ${STATUS[r.status][1]}">${STATUS[r.status][0]}</span></div>`;
function renderRecent() { const el = $('#recent'); if (el) el.innerHTML = load().slice(0, 4).map(card).join(''); }

function initForm() {
  const f = $('#photo'), prev = $('#preview');
  f.onchange = () => { const file = f.files[0]; if (!file) return; prev.src = URL.createObjectURL(file); prev.classList.remove('hidden'); $('#ph').classList.add('hidden'); };
  $('#form').onsubmit = e => {
    e.preventDefault();
    const cat = $('#cat').value;
    modal(`<div class="text-center py-4"><div class="spin mx-auto"></div><p id="ld" class="mt-5 text-cyan-300 font-semibold">ИИ анализирует фото с помощью YOLOv8...</p></div>`);
    setTimeout(() => { const l = $('#ld'); if (l) l.textContent = 'Определяются координаты...'; }, 1000);
    setTimeout(() => { success(addReport(cat, `${CATS[cat][0]} — обращение жителя`, $('#addr').value || 'Адрес определён по геометке', rnd(92, 99))); renderRecent(); e.target.reset(); prev.classList.add('hidden'); $('#ph').classList.remove('hidden'); }, 2200);
  };
}

/* ---------- dashboard ---------- */
let tab = 'all', catF = null;
function renderDash() {
  const all = load(), list = all.filter(r => (tab === 'all' || r.status === tab) && (!catF || r.cat === catF));
  const n = s => all.filter(r => r.status === s).length;
  $('#stats').innerHTML = [['Всего заявок', all.length, 'text-white', 'bg-zinc-400'], ['Новые', n('new'), 'text-cyan-300', 'bg-cyan-400'], ['В работе', n('work'), 'text-amber-300', 'bg-amber-400'], ['Решены', n('done'), 'text-emerald-300', 'bg-emerald-400']]
    .map(([t, v, c, b]) => `<div class="glass rounded-2xl p-5 relative overflow-hidden"><span class="absolute top-0 left-0 right-0 h-1 ${b}"></span><p class="text-xs text-zinc-400">${t}</p><p class="display text-3xl font-bold mt-1 ${c}">${v}</p></div>`).join('');
  document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.t === tab));
  $('#filt').innerHTML = catF ? `<button onclick="setCat(null)" class="text-xs rounded-full px-3 py-1 border border-cyan-400/40 text-cyan-300">Фильтр: ${CATS[catF][0]} ✕</button>` : '';
  $('#count').textContent = `Показано заявок: ${list.length}`;
  $('#list').innerHTML = list.length ? list.map(card).join('') : '<p class="text-zinc-500 text-center py-10">По этим условиям заявок нет. Смените вкладку или сбросьте фильтр.</p>';
}
function setCat(c) { catF = c; renderDash(); }
function show(t, c) { tab = t; catF = c; renderDash(); }

/* AI assistant */
function say(role, html) {
  const b = $('#chat'), u = role === 'u';
  b.insertAdjacentHTML('beforeend', `<div class="flex ${u ? 'justify-end' : ''}"><div class="max-w-[90%] rounded-2xl px-3 py-2 text-sm ${u ? 'bg-cyan-400/15 text-cyan-100' : 'bg-zinc-800/80 text-zinc-200'}">${html}</div></div>`);
  b.scrollTop = b.scrollHeight;
}
const AI_ENDPOINT = 'https://text.pollinations.ai/openai'; // бесплатный ИИ без ключа
let hist = [], fails = 0, hinted = false;
const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/\n/g, '<br>');

/* Локальные команды дашборда (фильтры, статистика). Возвращает null, если команда не распознана. */
function local(q) {
  const t = q.toLowerCase(), all = load(), n = s => all.filter(r => r.status === s).length, cnt = c => all.filter(r => r.cat === c).length;
  const key = /\bям[аыуе]?\b|асфальт|выбоин/.test(t) ? 'pothole' : /фонар|освещен|\bсвет\b/.test(t) ? 'light' : /мусор|свал/.test(t) ? 'trash' : /граффити|надпис/.test(t) ? 'graffiti' : null;
  if (/куда (скин|отпр|пойд|уход)|кому (уход|перед)|в как(ую|ие) служб/.test(t)) return 'Заявка уходит в профильную службу: ямы — в дорожную, фонари — в горсвет, мусор — в коммунальную, граффити — в службу благоустройства. Подать новую можно кнопкой «Новая заявка» вверху, а вернуться сюда — стрелкой ← в шапке.';
  if (/как (подат|отправ|созда|оставит)|подать заяв|создать заяв/.test(t)) return 'Нажмите «Новая заявка» вверху страницы, загрузите фото и выберите категорию. ИИ определит дефект и координаты за пару секунд. Назад ведёт стрелка ← в шапке.';
  if (/срочн|приоритет|опасн/.test(t)) { show('new', 'pothole'); return `Самые опасные для транспорта — ямы. Новых заявок по ним: ${all.filter(r => r.cat === 'pothole' && r.status === 'new').length}. Показал их в списке.`; }
  if (/больше всего|чаще всего|самая проблемн|популярн/.test(t)) { const top = Object.keys(CATS).sort((a, b) => cnt(b) - cnt(a))[0]; show('all', top); return `Чаще всего жители сообщают о теме «${CATS[top][0]}»: ${cnt(top)} заявок. Отфильтровал список.`; }
  if (key && /заяв|покаж|найд|есть|скольк|сколько|список/.test(t)) { show('all', key); return `По теме «${CATS[key][0]}» найдено ${cnt(key)} заявок. Показываю их в списке.`; }
  if (/в работе|выполняют/.test(t)) { show('work', null); return `Сейчас в работе ${n('work')} заявок. Открыл вкладку «В работе».`; }
  if (/новые|новых|ожидают/.test(t)) { show('new', null); return `Новых заявок: ${n('new')}. Они ещё ждут назначения службы.`; }
  if (/решен|устранен|закрыт/.test(t)) { show('done', null); return `Устранено ${n('done')} заявок — это ${Math.round(n('done') / all.length * 100)}% от всех.`; }
  if (/сколько.*заяв|статистик|итог|сводк/.test(t)) return `Всего заявок: ${all.length}. Новых: ${n('new')}, в работе: ${n('work')}, решено: ${n('done')}. Средняя уверенность ИИ — ${(all.reduce((s, r) => s + r.conf, 0) / all.length).toFixed(1)}%.`;
  return null;
}

/* Запасной режим без сервера: небольшой разговор по мелочам */
function offline(q) {
  const t = q.toLowerCase();
  if (/привет|здравств|добрый|хай/.test(t)) return 'Здравствуйте! Чем могу помочь?';
  if (/как дела|как ты/.test(t)) return 'Отлично, спасибо! Слежу за заявками города. А у вас как дела?';
  if (/кто ты|как тебя зовут|что ты умеешь/.test(t)) return 'Я ИИ-помощник CityFix. Умею искать и фильтровать заявки, объяснять статусы и, говорить на любые темы.';
  if (/спасибо|благодар/.test(t)) return 'Всегда пожалуйста!';
  if (/шутк|анекдот/.test(t)) return 'Почему дорожная яма не пошла на собеседование? Она боялась, что её опять «заделают».';
  const hint = hinted ? '' : '<br><span class="text-xs text-zinc-500">Бесплатный ИИ-сервис сейчас недоступен (нет интернета или лимит запросов). Попробуйте через минуту.</span>';
  hinted = true;
  return 'Не могу сейчас подключиться к ИИ-модели, поэтому отвечаю только по заявкам: статусы, темы, адреса.' + hint;
}

const SYSTEM = 'Ты — дружелюбный ИИ-помощник платформы CityFix AI (жалобы жителей на городские проблемы: ямы, фонари, мусор, граффити). Отвечай по-русски, понятно и по делу, как умный собеседник. Можешь говорить на любые темы: учёба, код, советы, идеи, шутки, общие вопросы. Если вопрос про заявки, опирайся на данные дашборда. Не выдумывай факты, если не уверен — так и скажи. Пиши коротко, без сложной разметки.';
async function llm(q) {
  const all = load(), c = k => all.filter(r => r.status === k).length;
  const context = `Заявок всего ${all.length} (новых ${c('new')}, в работе ${c('work')}, решено ${c('done')}). Последние: ` + all.slice(0, 8).map(r => `№${r.id} ${r.title}, ${r.addr}, ${STATUS[r.status][0]}`).join('; ');
  hist.push({ role: 'user', content: q });
  const msgs = [{ role: 'system', content: SYSTEM + ' Данные дашборда: ' + context }, ...hist.slice(-14)];
  const call = () => fetch(AI_ENDPOINT, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ model: 'openai', messages: msgs }) });
  try {
    let r = await call();
    if (r.status === 429) { await new Promise(s => setTimeout(s, 5000)); r = await call(); }
    if (!r.ok) throw new Error('ai ' + r.status);
    const d = await r.json(), text = d.choices[0].message.content;
    hist.push({ role: 'assistant', content: text });
    return esc(text);
  } catch (e) { hist.pop(); throw e; }
}

async function ask(q) {
  if (!q.trim()) return;
  say('u', esc(q));
  say('a', '<span class="text-zinc-500">печатает…</span>');
  const last = $('#chat').lastElementChild;
  let out = local(q);
  if (out) { hist.push({ role: 'user', content: q }, { role: 'assistant', content: out }); }
  else if (fails < 3) {
    try { out = await llm(q); fails = 0; } catch { fails++; }
  }
  if (!out) out = offline(q);
  setTimeout(() => { last.remove(); say('a', out); }, 350);
}

function initDash() {
  document.querySelectorAll('.tab').forEach(b => b.onclick = () => show(b.dataset.t, catF));
  $('#reset').onclick = () => { save(SEED); show('all', null); };
  $('#chatForm').onsubmit = e => { e.preventDefault(); const i = $('#q'); const v = i.value; i.value = ''; ask(v); };
  $('#chips').innerHTML = ['Сколько заявок?', 'Что в работе?', 'Где больше всего проблем?', 'Что срочное?', 'Как подать заявку?']
    .map(c => `<button class="chip text-xs rounded-full px-3 py-1.5 border border-zinc-700 hover:border-cyan-400 hover:text-cyan-300 transition">${c}</button>`).join('');
  document.querySelectorAll('.chip').forEach(b => b.onclick = () => ask(b.textContent));
  say('a', 'Привет! Я ИИ-помощник CityFix. Спросите про статусы заявок, найду нужные по теме или улице.');
  renderDash();
}

document.addEventListener('DOMContentLoaded', () => {
  shell();
  const m = $('#modal'); m.onclick = e => { if (e.target === m) closeModal(); };
  document.addEventListener('keydown', e => e.key === 'Escape' && closeModal());
  if (document.body.dataset.page === 'home') { renderCatalog(); renderRecent(); initForm(); }
  if (document.body.dataset.page === 'dash') initDash();
});
